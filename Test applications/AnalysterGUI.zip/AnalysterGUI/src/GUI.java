import java.awt.*;

import java.sql.*;
import java.text.SimpleDateFormat;

import javax.swing.*;

import javax.swing.border.TitledBorder;

import javax.swing.table.DefaultTableModel;

import javax.swing.table.TableColumn;

import javax.swing.JButton;

import javax.swing.JCheckBox;

import javax.swing.JFrame;

import javax.swing.JLabel;

import javax.swing.JPanel;

import javax.swing.JScrollPane;

import javax.swing.JTable;

import javax.swing.JTextField;

import com.ezware.oxbow.swingbits.table.filter.TableRowFilterSupport;

import java.awt.Event;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

import java.awt.event.WindowEvent;

import java.awt.event.WindowListener;

import java.util.*;

public class GUI extends Frame implements ActionListener, WindowListener {

	private JFrame frame;

	protected Container c;

	// private static JCheckBox symbol;

	private JTextField textForSymbol;

	private JLabel sqlLabel;

	// private static JTextField textForEndDate ;

	private JPanel panel_control;

	private JPanel panel_display;

	private JPanel panel_SQL;

	private JButton search;

	private JButton connect;

	// private static JButton update;

	private JButton displayAll;

	private JTable table;

	private JScrollPane scrollPane;

	private String sqlSearch;

	private String sqlC;
	private String sqlChange;

	private Vector columnNames = new Vector();

	private Vector data = new Vector();
	private JButton edit;
	private Statement stmt;

	public static void main(String[] args) {

		// TODO Auto-generated method stub

		GUI Analyster = new GUI();

		Analyster.createAndShowGUI();

	}

	public GUI() {

		frame = new JFrame();

		c = frame.getContentPane();

		panel_control = new JPanel();

		panel_display = new JPanel();

		panel_SQL = new JPanel();

		connect = new JButton("Connect");
		
		edit=new JButton("Edit");

		// panel_control.add(connect ,BorderLayout.WEST);

		textForSymbol = new JTextField("Enter Symbol Name", 20);

		// panel_control.add(textForSymbol );

		search = new JButton("Search");

		// panel_control.add(search );

		displayAll = new JButton("Display All");

		table = new JTable();

		scrollPane = new JScrollPane(table);

		// panel_control.add(displayAll );

		// c.add(panel_control ,BorderLayout.NORTH);

		// connect.addActionListener(this);

		// sqlC="select * from Assignment";

		// connection();

		// c.add(panel_display ,BorderLayout.CENTER);

		sqlLabel = new JLabel("Please add sql command here");

		// panel_SQL.add(sqlLabel );

		// c.add(panel_SQL,BorderLayout.SOUTH);

		// frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		// frame.setExtendedState(JFrame.MAXIMIZED_BOTH);

		// frame.setVisible(true);

		// frame.addWindowListener(this);

	}

	public void createAndShowGUI() {

		panel_control.add(connect, BorderLayout.WEST);

		// textForSymbol=new JTextField ("Enter Symbol Name" ,20);

		panel_control.add(textForSymbol);

		// search=new JButton("Search");

		panel_control.add(search);

		search.addActionListener(this);

		// displayAll=new JButton("Display All");

		panel_display.add(scrollPane);
		panel_display.add(edit);
		edit.addActionListener(this);

		panel_control.add(displayAll);

		c.add(panel_control, BorderLayout.NORTH);

		connect.addActionListener(this);

		// sqlC="select * from Assignment";

		// connection();

		c.add(panel_display, BorderLayout.CENTER);

		// sqlLabel=new JLabel("Please add sql command here" );

		panel_SQL.add(sqlLabel);

		c.add(panel_SQL, BorderLayout.SOUTH);

		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);

		frame.setVisible(true);

		frame.addWindowListener(this);

		// connection();

	}

	public void connection(String sql) {

		Connection con = null;

		stmt = null;

		columnNames = new Vector();

		data = new Vector();

		int columns = 0;

		// panel_display = new JPanel();

		String db_url, username, password;

		String jdbc_driver = "com.mysql.jdbc.Driver";

		db_url = "jdbc:mysql://elle.csndtbcukajz.us-west-2.rds.amazonaws.com:3306/ELLE_Fundamentals";

		username = "dbashicheng";

		password = "shicheng1221";

		try {

			Class.forName(jdbc_driver);

			// logWindow.sendMessages("Start to connect...");

			con = DriverManager.getConnection(db_url, username, password);

			// logWindow.sendMessages("Connect successfully!\n");

			stmt = con.createStatement();

			System.out.println("Connection successfully");

		}

		catch (Exception ex) {

			System.out
					.println("Cannot open AWS database -- make sure AWS is configured properly.");

			System.exit(1);

		}

		ResultSet rs = null;

		ResultSetMetaData metaData = null;

		try {

			rs = stmt.executeQuery(sql);

			metaData = rs.getMetaData();

		}

		catch (Exception ex) {

			System.out.println("Error: " + ex);

		}

		try {

			columns = metaData.getColumnCount();

			for (int i = 1; i <= columns; i++) {

				columnNames.addElement(metaData.getColumnName(i));

			}

			while (rs.next()) {

				Vector row = new Vector(columns);

				for (int i = 1; i <= columns; i++) {

					row.addElement(rs.getObject(i));

				}

				data.addElement(row);

			}

			rs.close();

			//stmt.close();

		}

		catch (Exception e) {

			System.out.println(e);

		}

		// table = new JTable(data, columnNames);

		table.setModel(new MyTableModel(data, columnNames));

		// table.getColumnClass(0);

		// table.getColumnClass(2);

		// table.isCellEditable(0, 0);

		// table.isCellEditable(0, 2);

		table.setPreferredScrollableViewportSize(new Dimension(800, 300));

		TableColumn column;

		for (int i = 0; i < table.getColumnCount(); i++) {

			column = table.getColumnModel().getColumn(i);

			column.setMaxWidth(400);

			// column.setPreferredWidth(500); //needs to modify

		}

		// scrollPane = new JScrollPane(table);

		// scrollPane.setSize(500, 100);

		// panel.setSize(500, 100);

		// panel_display.add(scrollPane);

		System.out.println("table added successfully");

	}

	// @Override

	public void actionPerformed(ActionEvent evt) {

		// panel_display = new JPanel();

		if ((JButton) evt.getSource() == connect) {

			System.out.println("Connection");

			// System.out.println(table.getRowCount());

			sqlC = "select * from Assignment";

			connection(sqlC);

			/*
			 * if (table.getRowCount()==0)
			 * 
			 * {
			 * 
			 * connection(sqlC);
			 * 
			 * panel_display.add(scrollPane);
			 * 
			 * }
			 * 
			 * else
			 * 
			 * {
			 * 
			 * panel_display.remove(scrollPane);
			 * 
			 * connection(sqlC);
			 * 
			 * panel_display.add(scrollPane);
			 * 
			 * }
			 */

		}

		else if ((JButton) evt.getSource() == search)

		{

			sqlSearch = "select * from Assignment where Symbol= '"
					+ textForSymbol.getText() + "'";

			// System.out.println(sqlSearch);

			// panel_display.remove(scrollPane);

			connection(sqlSearch);

			// panel_display.add(scrollPane);

		}
		else if ((JButton) evt.getSource() == edit){
			int row = table.getSelectedRow();  
            int col = table.getSelectedColumn();  
            table.isCellEditable(row, col);  
            try {
            	sqlChange="UPDATE Assignment SET " + columnNames.get(col) + " = '" + table.getValueAt(row, col)+ "' where inputLine = "+(row+1) + ";";
    			System.out.println(sqlChange);
            	stmt.executeUpdate(sqlChange);
    			connection(sqlC);
    		}
    		catch (Exception ex) {

    			System.out.println("Error: " + ex);

    		}
            
		} 

		TableRowFilterSupport.forTable(table).searchable(true).actions(true)
				.apply();

		c.revalidate();

	}

	public void windowOpened(WindowEvent e) {

		// TODO Auto-generated method stub

	}

	public void windowClosing(WindowEvent e) {

		// TODO Auto-generated method stub

		System.exit(0);

	}

	public void windowClosed(WindowEvent e) {

		// TODO Auto-generated method stub

	}

	public void windowIconified(WindowEvent e) {

		// TODO Auto-generated method stub

	}

	public void windowDeiconified(WindowEvent e) {

		// TODO Auto-generated method stub

	}

	public void windowActivated(WindowEvent e) {

		// TODO Auto-generated method stub

	}

	public void windowDeactivated(WindowEvent e) {

		// TODO Auto-generated method stub

	}

}

class MyTableModel extends DefaultTableModel {

	public MyTableModel(Object rowData[][], Object columnNames[]) {

		super(rowData, columnNames);

	}

	public MyTableModel(Vector data, Vector columnNames) {

		super(data, columnNames);

	}

	@Override
	public Class getColumnClass(int col) {

		if (col == 0 || col == 2) // second column accepts only Integer values
			return Integer.class;
		else if (col == 3 || col == 5)
			return SimpleDateFormat.class;

		else
			return String.class; // other columns accept String values

	}

	@Override
	public boolean isCellEditable(int row, int col) {

		if (col == 0) // first column will be uneditable

			return false;

		else
			return true;

	}

}
